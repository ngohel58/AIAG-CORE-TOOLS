import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, CheckCircle, Clock, AlertTriangle } from 'lucide-react';

const StatsOverview: React.FC = () => {
  const stats = [
    {
      title: 'Documents Generated',
      value: '247',
      change: '+12%',
      trend: 'up',
      icon: CheckCircle,
      color: 'text-green-600'
    },
    {
      title: 'AIAG Compliance',
      value: '100%',
      change: 'Maintained',
      trend: 'stable',
      icon: CheckCircle,
      color: 'text-green-600'
    },
    {
      title: 'Active Projects',
      value: '18',
      change: '+3 this week',
      trend: 'up',
      icon: Clock,
      color: 'text-blue-600'
    },
    {
      title: 'Pending Reviews',
      value: '5',
      change: '-2 from last week',
      trend: 'down',
      icon: AlertTriangle,
      color: 'text-orange-600'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {stats.map((stat, index) => (
        <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              {stat.title}
            </CardTitle>
            <stat.icon className={`h-5 w-5 ${stat.color}`} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
            <div className="flex items-center space-x-2 mt-1">
              <Badge 
                variant={stat.trend === 'up' ? 'default' : stat.trend === 'down' ? 'destructive' : 'secondary'}
                className="text-xs"
              >
                {stat.trend === 'up' && <TrendingUp className="h-3 w-3 mr-1" />}
                {stat.change}
              </Badge>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default StatsOverview;