import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Upload, Workflow, Shield, BarChart3, Plus, ArrowRight } from 'lucide-react';

const DashboardCards: React.FC = () => {
  const cards = [
    {
      icon: Upload,
      title: 'Import Master Data',
      description: 'Upload your master data sheet to auto-generate all AIAG documents',
      color: 'bg-gradient-to-br from-green-500 to-emerald-600',
      action: 'Upload File'
    },
    {
      icon: Plus,
      title: 'New Part Wizard',
      description: 'Step-by-step guided process for creating documents from scratch',
      color: 'bg-gradient-to-br from-blue-500 to-cyan-600',
      action: 'Start Wizard'
    },
    {
      icon: Workflow,
      title: 'Process Flow Chart',
      description: 'Create visual process maps with standard AIAG symbols',
      color: 'bg-gradient-to-br from-purple-500 to-violet-600',
      action: 'Create PFC'
    },
    {
      icon: Shield,
      title: 'Process FMEA',
      description: 'Generate comprehensive failure mode analysis with RPN calculations',
      color: 'bg-gradient-to-br from-red-500 to-rose-600',
      action: 'Create PFMEA'
    },
    {
      icon: BarChart3,
      title: 'Control Plan',
      description: 'Develop control plans for prototype, pre-launch, and production phases',
      color: 'bg-gradient-to-br from-orange-500 to-amber-600',
      action: 'Create Plan'
    },
    {
      icon: FileText,
      title: 'Document Library',
      description: 'Access and manage all your generated AIAG documents',
      color: 'bg-gradient-to-br from-indigo-500 to-blue-600',
      action: 'View Library'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {cards.map((card, index) => (
        <Card key={index} className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border-0 shadow-lg">
          <CardHeader className={`${card.color} text-white rounded-t-lg`}>
            <div className="flex items-center space-x-3">
              <card.icon className="h-8 w-8" />
              <div>
                <CardTitle className="text-lg">{card.title}</CardTitle>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <CardDescription className="text-gray-600 mb-4 text-sm leading-relaxed">
              {card.description}
            </CardDescription>
            <Button className="w-full group-hover:bg-gray-800 transition-colors">
              {card.action}
              <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default DashboardCards;