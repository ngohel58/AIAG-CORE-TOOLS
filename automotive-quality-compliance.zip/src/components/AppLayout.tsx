import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { useIsMobile } from '@/hooks/use-mobile';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Menu, FileText, Download, Upload, Workflow, Shield, BarChart3, Plus, ArrowRight, CheckCircle, Clock, AlertTriangle, TrendingUp, X, Settings, Zap, BookOpen, HelpCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

const AppLayout: React.FC = () => {
  const { sidebarOpen, toggleSidebar } = useAppContext();
  const isMobile = useIsMobile();

  const stats = [
    { title: 'Documents Generated', value: '247', change: '+12%', icon: CheckCircle, color: 'text-green-600' },
    { title: 'AIAG Compliance', value: '100%', change: 'Maintained', icon: CheckCircle, color: 'text-green-600' },
    { title: 'Active Projects', value: '18', change: '+3 this week', icon: Clock, color: 'text-blue-600' },
    { title: 'Pending Reviews', value: '5', change: '-2 from last week', icon: AlertTriangle, color: 'text-orange-600' }
  ];

  const cards = [
    { icon: Upload, title: 'Import Master Data', description: 'Upload your master data sheet to auto-generate all AIAG documents', color: 'bg-gradient-to-br from-green-500 to-emerald-600', action: 'Upload File' },
    { icon: Plus, title: 'New Part Wizard', description: 'Step-by-step guided process for creating documents from scratch', color: 'bg-gradient-to-br from-blue-500 to-cyan-600', action: 'Start Wizard' },
    { icon: Workflow, title: 'Process Flow Chart', description: 'Create visual process maps with standard AIAG symbols', color: 'bg-gradient-to-br from-purple-500 to-violet-600', action: 'Create PFC' },
    { icon: Shield, title: 'Process FMEA', description: 'Generate comprehensive failure mode analysis with RPN calculations', color: 'bg-gradient-to-br from-red-500 to-rose-600', action: 'Create PFMEA' },
    { icon: BarChart3, title: 'Control Plan', description: 'Develop control plans for prototype, pre-launch, and production phases', color: 'bg-gradient-to-br from-orange-500 to-amber-600', action: 'Create Plan' },
    { icon: FileText, title: 'Document Library', description: 'Access and manage all your generated AIAG documents', color: 'bg-gradient-to-br from-indigo-500 to-blue-600', action: 'View Library' }
  ];

  const menuItems = [
    { icon: FileText, label: 'Dashboard', active: true },
    { icon: Upload, label: 'Data Import', active: false },
    { icon: Workflow, label: 'Process Flow Chart', active: false },
    { icon: Shield, label: 'PFMEA', active: false },
    { icon: BarChart3, label: 'Control Plan', active: false },
    { icon: Settings, label: 'Settings', active: false },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white shadow-lg">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={toggleSidebar} className="text-white hover:bg-white/20">
                <Menu className="h-6 w-6" />
              </Button>
              <div className="flex items-center space-x-3">
                <FileText className="h-8 w-8" />
                <div>
                  <h1 className="text-xl font-bold">AIAG Core Tools Generator</h1>
                  <p className="text-blue-100 text-sm">Professional Quality Document Generation</p>
                </div>
              </div>
            </div>
            <Button variant="outline" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
              <Download className="h-4 w-4 mr-2" />Download Template
            </Button>
          </div>
        </div>
      </header>

      {/* Sidebar */}
      <div className={cn("fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-xl transform transition-transform duration-300 ease-in-out", sidebarOpen ? "translate-x-0" : "-translate-x-full")}>
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between p-4 border-b">
            <h2 className="text-lg font-semibold text-gray-800">Navigation</h2>
            <Button variant="ghost" size="icon" onClick={toggleSidebar} className="text-gray-500 hover:text-gray-700">
              <X className="h-5 w-5" />
            </Button>
          </div>
          <nav className="flex-1 p-4 space-y-2">
            {menuItems.map((item, index) => (
              <Button key={index} variant={item.active ? "default" : "ghost"} className={cn("w-full justify-start", item.active && "bg-blue-600 text-white hover:bg-blue-700")}>
                <item.icon className="h-4 w-4 mr-3" />{item.label}
              </Button>
            ))}
          </nav>
        </div>
      </div>
      
      {/* Overlay */}
      {sidebarOpen && isMobile && <div className="fixed inset-0 bg-black bg-opacity-50 z-40" onClick={toggleSidebar} />}
      
      {/* Main Content */}
      <main className="pt-4 pb-8 px-4 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome to AIAG Core Tools Generator</h1>
            <p className="text-gray-600 text-lg">Streamline your automotive quality documentation with AI-powered AIAG compliance</p>
          </div>
          
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {stats.map((stat, index) => (
              <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">{stat.title}</CardTitle>
                  <stat.icon className={`h-5 w-5 ${stat.color}`} />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                  <Badge className="text-xs mt-1"><TrendingUp className="h-3 w-3 mr-1" />{stat.change}</Badge>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {/* Dashboard Cards */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
            <div className="xl:col-span-2">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Core Tools</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {cards.map((card, index) => (
                  <Card key={index} className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border-0 shadow-lg">
                    <CardHeader className={`${card.color} text-white rounded-t-lg`}>
                      <div className="flex items-center space-x-3">
                        <card.icon className="h-8 w-8" />
                        <CardTitle className="text-lg">{card.title}</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent className="p-6">
                      <CardDescription className="text-gray-600 mb-4 text-sm leading-relaxed">{card.description}</CardDescription>
                      <Button className="w-full group-hover:bg-gray-800 transition-colors">
                        {card.action}<ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
            
            {/* Quick Actions */}
            <div className="xl:col-span-1">
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-xl font-bold text-gray-800">Quick Actions</CardTitle>
                  <CardDescription>Common tasks and helpful resources</CardDescription>
                </CardHeader>
                <CardContent>
                  {[{icon: Download, title: 'Download Master Template', badge: 'Popular'}, {icon: Upload, title: 'Quick Upload', badge: 'Fast'}, {icon: Zap, title: 'Auto-Generate Suite', badge: 'AI-Powered'}, {icon: BookOpen, title: 'AIAG Guidelines', badge: 'Reference'}, {icon: FileText, title: 'Recent Documents', badge: 'Recent'}, {icon: HelpCircle, title: 'Getting Started', badge: 'Tutorial'}].map((action, index) => (
                    <div key={index} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer group">
                      <div className="p-2 rounded-lg bg-gray-100 group-hover:bg-gray-200 transition-colors">
                        <action.icon className="h-5 w-5 text-gray-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className="font-medium text-gray-900 text-sm">{action.title}</h3>
                          <Badge className="bg-blue-500 text-white text-xs px-2 py-0.5">{action.badge}</Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AppLayout;