import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Download, FileText, Upload, Zap, BookOpen, HelpCircle } from 'lucide-react';

const QuickActions: React.FC = () => {
  const actions = [
    {
      icon: Download,
      title: 'Download Master Template',
      description: 'Get the Excel template with all required AIAG fields',
      badge: 'Popular',
      badgeColor: 'bg-green-500'
    },
    {
      icon: Upload,
      title: 'Quick Upload',
      description: 'Drag and drop your completed data sheet',
      badge: 'Fast',
      badgeColor: 'bg-blue-500'
    },
    {
      icon: Zap,
      title: 'Auto-Generate Suite',
      description: 'Create PFC, PFMEA, and Control Plan instantly',
      badge: 'AI-Powered',
      badgeColor: 'bg-purple-500'
    },
    {
      icon: BookOpen,
      title: 'AIAG Guidelines',
      description: 'Access built-in compliance documentation',
      badge: 'Reference',
      badgeColor: 'bg-orange-500'
    },
    {
      icon: FileText,
      title: 'Recent Documents',
      description: 'Continue working on your latest projects',
      badge: 'Recent',
      badgeColor: 'bg-gray-500'
    },
    {
      icon: HelpCircle,
      title: 'Getting Started',
      description: 'Interactive tutorial and best practices',
      badge: 'Tutorial',
      badgeColor: 'bg-indigo-500'
    }
  ];

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl font-bold text-gray-800">Quick Actions</CardTitle>
        <CardDescription>Common tasks and helpful resources</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {actions.map((action, index) => (
            <div key={index} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer group">
              <div className="p-2 rounded-lg bg-gray-100 group-hover:bg-gray-200 transition-colors">
                <action.icon className="h-5 w-5 text-gray-600" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2 mb-1">
                  <h3 className="font-medium text-gray-900 text-sm">{action.title}</h3>
                  <Badge className={`${action.badgeColor} text-white text-xs px-2 py-0.5`}>
                    {action.badge}
                  </Badge>
                </div>
                <p className="text-xs text-gray-600 leading-relaxed">{action.description}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default QuickActions;